function isspace(s) {
    if(s == " " || s == "\t" || s == "\n") return true;
    return false;
}

function get_body() {
    return document.getElementsByTagName("body").item(0);
}

function clear_children(o) {
    while(o.childNodes.length > 0) {
	o.removeChild(o.childNodes.item(0));
    }
}

function replace_keywords(msg) {
	var re = /\$[^\t\n$]*\$/g;
	var m;
	var result = "";
	var start, end;

	// alert(msg);
	m = re.exec(msg);
	start = end = 0;
	while(m) {
		end = RegExp.leftContext.length;
		if(start != end) result += msg.substring(start, end);
		if(RegExp.lastMatch == "$$")
			result += "$";
		else {
			m = RegExp.lastMatch.substring(1, RegExp.lastMatch.length - 1);
			result += "<a href='"+ gingin_url + "/show_kw_docs/" + m + "'>" + m + "</a>";
		}
		start = re.lastIndex;
		m = re.exec(msg);
	}
	end = msg.length;
	if(start != end) result += msg.substring(start, end);

	return result;
}

function replace_style(msg) {
	var len = msg.length;
	var i, ni, oi;
	var c;
	var result = "";

	for(i = oi = 0; i < len; i++) {
		c = msg.charAt(i);
		switch(c) {
		case '`':
			if(oi != i) result += msg.substring(oi, i);
			if(msg.substring(i, i + 3) == '```') {
				oi = i + 3;
				ni = msg.indexOf('\'\'\'');
				if(ni >= 0) {
					result += "<div class='quote'>" + msg.substring(oi, ni) + "</div>";
					oi = ni + 3;
					i = ni + 2;
				} else {
					result += '```';
					i = i + 2;
				}
			} else {
				oi = i + 1;
				ni = msg.indexOf('\'', i);
				if(ni >= 0) {
					i = ni;
					result += "<b>" + msg.substring(oi,i) + "</b>";
					oi = i + 1;
				} else {
					result += '`';
				}
			}
			break;
		default:
			break;
		}
	}
	if(len != oi) result += msg.substring(oi, i);
	return result;
}

function replace_url(msg) {
	var re = /(linkname:([^ ]+|\[[^\]]*\])\ |\[)?((http:\/\/|ftp:\/\/|attach:|amazon_isbn:|amazon_thumb:)[^ \n\t\]]+\]?)/gi;
	var result = "";
	var start = 0;
	var end = 0;
	var mo, m, r;
	var url;
	var override_txt = "";

	mo = re.exec(msg);
	while(mo) {
		end = RegExp.leftContext.length;
		m = RegExp.lastMatch;
		if(m.charAt(0) != '[') {
			url = m;
		} else {
			url = mo[3];
			url = url.substring(0, url.length - 1);
		}
		txt = m;
		if(url.substring(0, 9) == "linkname:") {
			override_txt = mo[1].substring(9, mo[1].length - 1)
			if(override_txt.charAt(0) == '[')
				override_txt = override_txt.substring(1, override_txt.length - 1);
			url = mo[3]
		}
		if(url.substring(0, 7) == "attach:") {
			txt = url.substring(7);
		}
		if(url.substring(0, 12) == "amazon_isbn:") {
			txt = url.substring(12);
		}
		if(url.substring(0, 13) == "amazon_thumb:") {
			txt = url.substring(13);
		}
		if(url.substring(0, 7) == "attach:") {
			url = gingin_url + "/get_afile/" +
				doc_id + "/" + txt;
		}
		if(url.substring(0, 12) == "amazon_isbn:") {
			url = "http://www.amazon.com/gp/product/" + txt;
			txt = "ISBN:" + txt;
		}
		if(url.substring(0, 13) == "amazon_thumb:") {
			url = "http://images.amazon.com/images/P/" + txt + ".01._SCTHUMBZZZ_.jpg";
		}
		if(override_txt != "") txt = override_txt;
		if(m.charAt(0) != '[')
			r = "<a href=\"" + url + "\">" + txt + "</a>";
		else
			r = "<img src=\"" + url + "\"/>";
		result += replace_keywords(replace_style(msg.substring(start, end)));
		result += r;
		start = re.lastIndex;
		mo = re.exec(msg);
	}
	if(start != msg.length)
		result += replace_keywords(replace_style(msg.substring(start, msg.length)));
	return result;
}


function show_msg(msg) {
	var i, oi, j, len;
	var sp = 0;
	var c;
	var lst_lvl = 0;
	var lst_lvl_sp = new Array();
	var lst_lvl_type = new Array();
	var result = "";
	var preflag = 0;

	len = msg.length;
	for(i = oi = 0; i < len; i++) {
		c = msg.charAt(i);
		switch(c) {
		case ' ':
			sp++;
			break;
		case '\r':
			break;
		case '\n':
			while(lst_lvl > 0) {
				if(lst_lvl_type[lst_lvl - 1] == '*')
					result += '</ul>\n';
				else
					result += '</ol>\n';
				lst_lvl--;
			}
			if(sp == 0 && preflag == 0) {
				if(oi != i) result += replace_url(msg.substring(oi, i));
				result += '<p/>\n';
				oi = i + 1
			}
			sp = 0;
			break;
		case '=':
			if(oi != i) result += replace_url(msg.substring(oi, i));
			while(lst_lvl > 0) {
				if(lst_lvl_type[lst_lvl - 1] == '*')
					result += '</ul>\n';
				else
					result += '</ol>\n';
				lst_lvl--;
			}
			for(j = 0; j < 3; j++, i++) {
				if(msg.charAt(i) != '=')
					break;
			}
			result += '<H' + j + '>';
			oi = i;
			i = msg.indexOf('=', i);
			if(i == -1) i = len;
			result += replace_url(msg.substring(oi, i));
			result += '</H' + j + '>';
			i += j - 1;
			oi = i + 1;
			break;
		case '*':
		case '#':
			if(oi != i) result += replace_url(msg.substring(oi, i));
			if(lst_lvl == 0 || lst_lvl_sp[lst_lvl - 1] < sp) {
				if(c == '*')
					result += '<ul>\n';
				else
					result += '<ol>\n';
				lst_lvl_type[lst_lvl] = c;
				lst_lvl_sp[lst_lvl++] = sp;
			} else {
				while(lst_lvl_sp[lst_lvl - 1] > sp) {
					if(lst_lvl_type[lst_lvl - 1] == '*')
						result += '</ul>\n';
					else
						result += '</ol>\n';
					lst_lvl--;
				}
			}
			result += '<li>';
			i++;
			oi = i;
			i = msg.indexOf('\n', i);
			if(i == -1) i = len;
			result += replace_url(msg.substring(oi, i)) + '</li>\n';
			sp = 0;
			oi = i + 1;
			break;
		case '{':
			if(oi != i) result += replace_url(msg.substring(oi, i));
			oi = i;
			if(msg.substring(i, i + 3) == "{{{") {
				result +=  "<pre>";

				i += 3;
				oi = i;
				j = i + msg.substring(i).search("\n}}}");
				for(; i < j; i++) {
					c = msg.charAt(i);
					if(c == "<") {
						result += replace_url(msg.substring(oi, i));
						result += "&lt;";
						oi = i + 1;
					} else if(c == "&" && msg.charAt(i+1) != '#') {
						// &#????; should be avoid
						result += replace_url(msg.substring(oi, i));
						result += "&amp;";
						oi = i + 1;
					}
				}
				result += replace_url(msg.substring(oi, i));
				result += "</pre>\n";
				i += 3;
				oi = i + 1;
				break;
			}
		default:
			while(lst_lvl > 0) {
				if(lst_lvl_type[lst_lvl - 1] == '*')
					result += '</ul>\n';
				else
					result += '</ol>\n';
				lst_lvl--;
			}
			i = msg.indexOf('\n', i);
			if(i == -1) i = len;
			sp = 0;
			break;
		}
	}
	if(oi != i)
		result += replace_url(msg.substring(oi, i));
	while(lst_lvl > 0) {
		if(lst_lvl_type[lst_lvl - 1] == '*')
			result += '</ul>\n';
		else
			result += '</ol>\n';
			lst_lvl--;
	}
	return result;
}

function divide_into_pages(data) {
    var pages = data.split("\n----\n");
    var page,i, h, t;
    
    for(i = 0; i < pages.length; i++) {
	page = pages[i];
	for(h = 0; isspace(page.charAt(h)); h++);
	for(t = page.length - 1; isspace(page.charAt(t)); t--);
	t++;
	pages[i] = page.substring(h, t);
    }
    return pages;
}

function show_page_data(data) {
    var content = document.getElementById("content");
    
    clear_children(content);
    content.innerHTML = show_msg(data);
}

function show_page(pages, idx) {
    var page_info = document.getElementById("page_info");
    var txt;
    
    show_page_data(pages[idx]);
    if(page_info) {
	txt = document.createTextNode("" + (idx + 1) + "/" + pages.length);
	clear_children(page_info);
	page_info.appendChild(txt);
    }
}

function initial() {
    var src = document.getElementById("src");
    var body = get_body();
    var content, current = 0;
    var pages;
    var go_next_page, keydown, init_event, remove_event;
    var handle_go_page, stop_go_page, start_go_page;
    var go_buffer;
    var go_current;
    
    pages = divide_into_pages(src.value);
    current = 0;
    content = document.createElement("div");
    content.setAttribute("id", "content");
    src.parentNode.insertBefore(content, src);
    src.parentNode.removeChild(src);
    
    start_go_page = function(init_go_current) {
	var txt;
	
	remove_event();
	go_current = init_go_current;
	document.addEventListener("keydown", handle_go_page, false);
	go_buffer = document.createElement("div");
	go_buffer.setAttribute("id", "go_buffer");
	body.appendChild(go_buffer);
	
	txt = document.createTextNode('' + go_current);
	clear_children(go_buffer);
	go_buffer.appendChild(txt);
    }
    
    stop_go_page = function() {
	document.removeEventListener("keydown", handle_go_page, false);
	init_event();
	body.removeChild(go_buffer);
    }
    
    handle_go_page = function(evt) {
	var txt;
	
	if(evt.keyCode == 13) {
	    stop_go_page();
	    if(go_current > 0 && go_current <= pages.length) {
		current = go_current - 1;
		show_page(pages, current);
	    }
	    return;
	}
	if(evt.keyCode < 48 || evt.keyCode >= 57) {
	    stop_go_page();
	    return;
	}
	go_current = go_current * 10 + evt.keyCode - 48;
	txt = document.createTextNode('' + go_current);
	clear_children(go_buffer);
	go_buffer.appendChild(txt);
    }
    
    go_next_page = function(evt) {
	if(current < (pages.length - 1)) {
	    current = current + 1;
	    show_page(pages, current);
	}
    }
    
    keydown = function(evt) {
	if(evt.keyCode > 48 && evt.keyCode < 58) { // 1 ~ 9
	    start_go_page(evt.keyCode - 48);
	    return;
	}
	switch(evt.keyCode) {
	case 37:
	    if(current > 0) current--;
	    show_page(pages, current);
	    break;
	case 0x20:
	case 39:
	    if(current < (pages.length - 1)) current++;
	    show_page(pages, current);
	    break;
	case 36: // home
	    current = 0;
	    show_page(pages, current);
	    break;
	case 35: // end
	    current = pages.length - 1;
	    show_page(pages, current);
	    break;
	case 13: // CR
	    break;
	default:
	    //alert(evt.keyCode);
	}
    }
    
    show_page(pages, 0);
    init_event = function() {
	document.addEventListener("click", go_next_page, false);
	document.addEventListener("keydown", keydown, false);
    }
    remove_event = function() {
	document.removeEventListener("click", go_next_page, false);
	document.removeEventListener("keydown", keydown, false);
    }
    
    init_event();
}
